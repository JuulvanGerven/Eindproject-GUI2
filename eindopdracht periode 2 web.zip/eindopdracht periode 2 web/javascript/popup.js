function help1(){
    var x = document.getElementById("text2");
    if (x.style.display === "block"){
        x.style.display = "none"
    } else {
        x.style.display = "block"
    }
}
function help2(){
    var x = document.getElementById("text3");
    if (x.style.display === "block"){
        x.style.display = "none"
    } else {
        x.style.display = "block"
    }
}
function help3(){
    var x = document.getElementById("text4");
    if (x.style.display === "block"){
        x.style.display = "none"
    } else {
        x.style.display = "block"
    }
}
function help4(){
    var x = document.getElementById("text5");
    if (x.style.display === "block"){
        x.style.display = "none"
    } else {
        x.style.display = "block"
    }
}
